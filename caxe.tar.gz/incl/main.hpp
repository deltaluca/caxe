#ifndef main_hpp
#define main_hpp

extern int _threadcnt;

#endif
